
const express = require("express"); 
const fs = require("fs");
let bodyParser = require("body-parser");
const path = require("path");


let app = express();

app.set("views", path.join(__dirname, "views"));
app.set("view engine", "hbs")



app.use(bodyParser.urlencoded({extended: false}));
app.use(bodyParser.json())
app.use(express.static(path.join(__dirname, "./public")));

let product = JSON.parse(fs.readFileSync("./data/data.json"));
let accounts = JSON.parse(fs.readFileSync("./data/accounts.json"))

app.get("/admin/delete", (req, res)=>{
    let id = req.query.id;
    console.log(id);
    elementsVisible = true;
    for(let i = 0; i < product.length; i++){
        if(product[i].id == id){
            product.splice(i, 1);
        }
    }
    
    let responseArray = product;
    res.render("catalog", {responseArray})
})

app.get("/account/login", (req, res)=>{
    res.render("login");
})

app.get("/account/register", (req, res)=>{
    res.render("register");
})

app.post("/account/login", (req, res)=>{
    let account = req.body;
    console.log();
    for(let i = 0; i < accounts.length; i++){
        if(account.name == accounts[i].name){
            console.log("account exists");
            res.sendStatus(202);
            res.end();
            return;
        }
    }
    res.sendStatus(404);
    res.end();
    console.log("account not found");  
})

app.post("/account/register", (req, res)=>{
    let account = req.body;
    console.log();
    for(let i = 0; i < accounts.length; i++){
        if(account.name == accounts[i].name){
            console.log("account with that name alredy exists");
            res.sendStatus(404);
            return;
        }  
    }
    res.sendStatus(202);
    accounts.push(account);
    console.log(accounts);   
    res.end();
})

app.post("/admin/change", (req, res)=>{
    let reqId = req.query.name;
    for(let i = 0; i < product.length; i++){
        if(product[i].id == reqId){
            if(req.body.id != ""){
                product[i].id = req.body.id;
            }
            if(req.body.name != ""){
                product[i].name = req.body.name;
            }
            if(req.body.desc != ""){
                product[i].desc = req.body.desc;
            }
            res.send(JSON.stringify(product[i].id));
            console.log("response send");
            return;
        }
    }
})

app.post("/create/new", (request, response)=>{
    console.log(request.body)
    let object = request.body;
    if(!object.img){
        object.img = "notFound.jpg"
    }
    product.push(object);
    response.sendStatus(200);
})

app.get("/admin/create", (req, res)=>{
    res.render("create");
})



app.get("/product", (req, res)=>{
    let name = req.query.name;
    let responseObject;
    for(let i = 0; i < product.length; i++){
        if(product[i].id == name){
            responseObject = product[i];
            res.render("productInfo", responseObject);
            return;
        }
    }
    res.render("notFound");
})


app.get("/catalog", (req, res)=>{
    let counter = 0;
    let name = req.query.filter;
    let responseArray = [];
    let elementsVisible = false;
    for(let i = 0; i < product.length; i++){
        if(!name ||
          (product[i].name).includes(name.toLowerCase()) || 
          (product[i].ccal) == name ||
          (product[i].fats) == name){
            responseArray[counter] = product[i];
            counter++;
            elementsVisible = true;
        }
    }
    res.render("catalog", {responseArray, elementsVisible})
})





app.listen(3000)