
const express = require("express"); 
const fs = require("fs");
let bodyParser = require("body-parser");
const path = require("path");


let app = express();

app.set("views", path.join(__dirname, "views"));
app.set("view engine", "hbs")



app.use(bodyParser.urlencoded({extended: false}));
app.use(bodyParser.json())
app.use(express.static(path.join(__dirname, "./public")));

let product = JSON.parse(fs.readFileSync("./data/data.json"));

app.get("/admin/delete", (req, res)=>{
    let id = req.query.id;
    console.log(id);
    elementsVisible = true;
    for(let i = 0; i < product.length; i++){
        if(product[i].id == id){
            product.splice(i, 1);
        }
    }
    
    let responseArray = product;
    res.render("catalog", {responseArray})
})

app.post("/admin/change", (req, res)=>{
    let reqId = req.query.name;
    for(let i = 0; i < product.length; i++){
        if(product[i].id == reqId){
            if(req.body.id != ""){
                product[i].id = req.body.id;
            }
            if(req.body.name != ""){
                product[i].name = req.body.name;
            }
            if(req.body.desc != ""){
                product[i].desc = req.body.desc;
            }
            console.log(product[i]);
            return;
        }
    }
})

app.post("/create/new", (request, response)=>{
    console.log(request.body)
    let object = request.body;
    if(!object.img){
        object.img = "notFound.jpg"
    }
    product.push(object);
    response.sendStatus(200);
})

app.get("/admin/create", (req, res)=>{
    res.render("create");
})



app.get("/product", (req, res)=>{
    let name = req.query.name;
    let responseObject;
    for(let i = 0; i < product.length; i++){
        if(product[i].id == name){
            responseObject = product[i];
        }
    }
    res.render("productInfo", responseObject)
})

// app.put("/admin/change", (req, res)=>{
//     let object = JSON.parse(req.body);
//     for(let i = 0; i < food.length; i++){
//         if(food[i].name == object.name){
//             food[i].specs = object.specs
//         }
//     }
// })

app.get("/catalog", (req, res)=>{
    let counter = 0;
    let name = req.query.filter;
    let responseArray = [];
    let elementsVisible = false;
    for(let i = 0; i < product.length; i++){
        if(!name ||
          (product[i].name).includes(name.toLowerCase()) || 
          (product[i].ccal) == name ||
          (product[i].fats) == name){
            responseArray[counter] = product[i];
            counter++;
            elementsVisible = true;
        }
    }
    res.render("catalog", {responseArray, elementsVisible})
})





app.listen(3000)