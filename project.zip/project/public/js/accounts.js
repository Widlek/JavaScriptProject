function goToRegisterPage(){
    document.location = "/account/register";
}

function goToLoginPage(){
    document.location = "/account/login";
}