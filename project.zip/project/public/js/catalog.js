async function testFunc(){
    let data = document.getElementById('name').value;
    document.location  = `/catalog?filter=${data}`;
}

const deleteButtons = document.querySelectorAll("[id='testButton']");
const descriptionButtons = document.querySelectorAll("[id='descriptionButton']");


deleteButtons.forEach(element => {
    element.addEventListener('click', async function deleteById(event){
        let id = event.target.parentNode.id;
        console.log(id);
        const response = fetch(`/admin/delete?id=${id}`);
        document.location.reload();
        return;
    })
});

descriptionButtons.forEach(element =>{
    element.addEventListener("click", async function deleteById(event){
        let id = event.target.parentNode.id;
        document.location  = `/product?name=${id}`;
    })
})

function createNew(){
    document.location = `/admin/create`;
}

function goToRegisterPage(){
    document.location = "/account/register";
}

function goToLoginPage(){
    document.location = "/account/login";
}

// editButtons.forEach(element => {
//     element.addEventListener('click', function deleteById(event){
//         let id = event.target.parentNode.id;
//         let newName = document.createElement("input");
//         newName.appendChild(id);
//         let newSpecs = document.createElement("input");
//         newSpecs.appendChild(id);
//         let applyButton = document.createElement("button");
//         applyButton.appendChild(id);
//         applyButton.addEventListener('click', async function applyChanges(event){

//             let requestObject = {
//                 name: newName.value,
//                 specs: newSpecs.value,
//             }
//             let data = {
//                 method: "PUT",
//                 body: JSON.stringify(requestObject),
//             }
//             fetch("/admin/change", data);
//         })
//     })
// });



