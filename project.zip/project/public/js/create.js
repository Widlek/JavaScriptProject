function sendData(){
    let data = {
        name: document.getElementById("name").value,
        desc: document.getElementById("desc").value,
        id: document.getElementById("id").value,
    }

    let sendedData = JSON.stringify(data);
    fetch("/create/new", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
          },
        body: sendedData,
    }) 
    console.log(sendedData);
}