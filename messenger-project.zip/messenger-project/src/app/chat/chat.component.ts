import { Component, EventEmitter, Output } from '@angular/core';
import { Input } from '@angular/core';
import { Chat } from '../chat';
import { NgClass, NgIf, NgStyle } from '@angular/common';
import { FormsModule, NgModel, NgSelectOption } from '@angular/forms';
import { Message } from '../message';
import { ChatService } from '../chat.service';
import { UserService } from '../user.service';
import { User } from '../user';
import { MessageComponent } from '../message/message.component';
import { MessageEditComponent } from '../message-edit/message-edit.component';

@Component({
  selector: 'app-chat',
  standalone: true,
  imports: [NgIf, FormsModule, MessageComponent, NgClass, MessageEditComponent, NgStyle],
  templateUrl: './chat.component.html',
  styleUrl: './chat.component.css'
})
export class ChatComponent {
  constructor(public chatService: ChatService, public userService: UserService){};
  @Input() chat:Chat | undefined = undefined;
  @Input() user: User | undefined = undefined;

  @Output() leaveEvent = new EventEmitter<User>();

  text: string = "";

  editing: boolean = false;

  selectedMessage: Message | undefined = undefined;

  x:string = '0px';
  y:string = '0px';

  editMenu = document.getElementById("app-message-edit");

  mouseUpdate(event: MouseEvent){
    this.x = event.pageX.toString() + 'px';
    this.y = event.pageY.toString() + 'px';

    console.log(this.x, this.y);

  }

  leaveChat(){
    if(this.chat && this.user){
      this.chatService.deleteUser(this.chat, this.user);
      this.leaveEvent.emit(this.user);
      this.chatService.setSelectedChat(undefined);
    }
  }

  editMessage(message: Message){
    if(this.text != "" && this.text != undefined){
      message.text = this.text;
      this.editing = false;
    }
  }

  sendMessage(){
    if(this.text != ""){
      let newMessage:Message = {
        text: this.text,
        date: new Date(),
        sender: this.userService.getCurrentUser(),
      }
      if(this.chat) this.chatService.sendMessage(this.chat, newMessage);
    }
  }

  visible: boolean = true;
  toggle(message: Message){
    this.visible = !this.visible;
  }

}
