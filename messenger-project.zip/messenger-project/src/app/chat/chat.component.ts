import { Component } from '@angular/core';
import { Input } from '@angular/core';
import { Chat } from '../chat';
import { NgIf } from '@angular/common';
import { FormsModule, NgModel } from '@angular/forms';
import { Message } from '../message';
import { ChatService } from '../chat.service';
import { UserService } from '../user.service';

@Component({
  selector: 'app-chat',
  standalone: true,
  imports: [NgIf, FormsModule],
  templateUrl: './chat.component.html',
  styleUrl: './chat.component.css'
})
export class ChatComponent {
  constructor(public chatService: ChatService, public userService: UserService){};
  @Input() chat:Chat | undefined = undefined;

  text: string = "";



  leaveChat(){
    if(this.chat){
      let currentUser = sessionStorage.getItem("currentUser");
      
    }
  }
  sendMessage(){
    if(this.text != ""){
      let newMessage:Message = {
        text: this.text,
        date: new Date(),
        sender: undefined,
      }
      if(this.chat) this.chatService.sendMessage(this.chat, newMessage)
    }


  }

}
