import { Component, EventEmitter, Output } from '@angular/core';
import { Input } from '@angular/core';
import { Chat } from '../chat';
import { NgIf } from '@angular/common';
import { FormsModule, NgModel } from '@angular/forms';
import { Message } from '../message';
import { ChatService } from '../chat.service';
import { UserService } from '../user.service';
import { User } from '../user';

@Component({
  selector: 'app-chat',
  standalone: true,
  imports: [NgIf, FormsModule],
  templateUrl: './chat.component.html',
  styleUrl: './chat.component.css'
})
export class ChatComponent {
  constructor(public chatService: ChatService, public userService: UserService){};
  @Input() chat:Chat | undefined = undefined;
  @Input() user: User | undefined = undefined;

  @Output() leaveEvent = new EventEmitter<User>();

  text: string = "";

  editing: boolean = false;

  leaveChat(){
    if(this.chat && this.user){
      this.chatService.deleteUser(this.chat, this.user);
      this.leaveEvent.emit(this.user);
      this.chatService.setSelectedChat(undefined);
    }
  }

  editMessage(message: Message){
    if(this.text != "" && this.text != undefined){
      message.text = this.text;
      this.editing = false;
    }
  }

  sendMessage(){
    if(this.text != ""){
      let newMessage:Message = {
        text: this.text,
        date: new Date(),
        sender: undefined,
      }
      if(this.chat) this.chatService.sendMessage(this.chat, newMessage);
    }


  }

}
