import { NgIf } from '@angular/common';
import { Component, Input, Output, EventEmitter } from '@angular/core';
import { Chat } from '../chat';
import { ChatlistComponent } from '../chatlist/chatlist.component';

@Component({
  selector: 'app-chat-preview',
  standalone: true,
  imports: [ChatlistComponent, NgIf],
  templateUrl: './chat-preview.component.html',
  styleUrl: './chat-preview.component.css'
})
export class ChatPreviewComponent {
  @Input() chat:Chat = {
    id: 0,
    name: "",
    messages: [],
    members: [],
    picture: "",
  }
  
  @Output() selectChatEvent = new EventEmitter<Chat>();

  selectChat(chat: Chat){
    this.selectChatEvent.emit(chat);
  }
}
