import { Injectable } from '@angular/core';
import { User } from './user';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  userList:User[] = [];

  currentUser: User | undefined = undefined;

  getCurrentUser(){
    return this.currentUser;
  }

  setCurrentUser(user: User){
    this.currentUser = user;
    return this.currentUser;
  }

  findUserById(id: number){
    for(let i = 0 ; i < this.userList.length; i++){
      if(this.userList[i].id == id){
        return this.userList[i];
      }
    }
    return undefined;
  }

  createUser(name:string, password:string, profilePicture?: string, displayedName?:string, status?:string){
    let user = {
      id: this.userList.length,
      name: name,
      password: password,
      profilePicture: profilePicture || "",
      status: status || "",
      displayedName: displayedName || "",
    }
    this.userList.push(user);
    return user;
  }
  constructor() { }
}
