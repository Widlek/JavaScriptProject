import { Component, inject } from '@angular/core';
import { ChatPreviewComponent } from '../chat-preview/chat-preview.component';
import { ChatService } from '../chat.service';
import { UserService } from '../user.service';
import { Message } from '../message';
import { Chat } from '../chat';
import { NgIf } from '@angular/common';
import { ChatComponent } from '../chat/chat.component';
import { LoginScreenComponent } from '../login-screen/login-screen.component';
import { User } from '../user';

@Component({
  selector: 'app-chatlist',
  standalone: true,
  imports: [ChatlistComponent, ChatPreviewComponent, NgIf, ChatComponent, LoginScreenComponent],
  templateUrl: './chatlist.component.html',
  styleUrl: './chatlist.component.css'
})
export class ChatlistComponent {
  constructor(public chatService: ChatService, public userService: UserService){};
  testChat:Chat = this.chatService.createChat("test chat", this.userService.userList);
  testChat2:Chat = this.chatService.createChat("test chat 2");

  filteredChats: Chat[] | undefined = [];

  testMsg: Message = {
    text: "Hello world!",
    date: undefined,
    sender: undefined,
  }

  ngOnInit(){
    this.chatService.sendMessage(this.testChat2, this.testMsg);
    this.userService.createUser("testUser", "123");
    this.userService.createUser("User2", "1234");
  }

  setChat(value: Chat | undefined){
    console.log(value);
    this.chatService.setSelectedChat(value);
    return value;
  }
  
  setUser(user: User){
    if(user){
      this.filteredChats = [];
      this.userService.setCurrentUser(user);  
      for(let i = 0; i < this.chatService.chatList.length; i++){
        if(this.chatService.chatList[i].members.includes(user)){
          this.filteredChats?.push(this.chatService.chatList[i]);
        }
      }
    }
  }

}
