import { Component, inject } from '@angular/core';
import { ChatPreviewComponent } from '../chat-preview/chat-preview.component';
import { ChatService } from '../chat.service';
import { UserService } from '../user.service';
import { Message } from '../message';
import { Chat } from '../chat';
import { NgIf } from '@angular/common';
import { ChatComponent } from '../chat/chat.component';

@Component({
  selector: 'app-chatlist',
  standalone: true,
  imports: [ChatlistComponent, ChatPreviewComponent, NgIf, ChatComponent],
  templateUrl: './chatlist.component.html',
  styleUrl: './chatlist.component.css'
})
export class ChatlistComponent {
  constructor(public chatService: ChatService, public userService: UserService){};
  testChat:Chat = this.chatService.createChat("test chat");
  testChat2:Chat = this.chatService.createChat("test chat 2");
  testMsg: Message = {
    text: "Hello world!",
    date: undefined,
    sender: undefined,
  }
  ngOnInit(){
    this.chatService.sendMessage(this.testChat2, this.testMsg);
    
  }
  setChat(value: Chat | undefined){
    console.log(value);
    this.chatService.setSelectedChat(value);
    return value;
  }
  
}
