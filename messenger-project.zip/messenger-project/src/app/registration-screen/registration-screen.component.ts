import { Component } from '@angular/core';

@Component({
  selector: 'app-registration-screen',
  standalone: true,
  imports: [],
  templateUrl: './registration-screen.component.html',
  styleUrl: './registration-screen.component.css'
})
export class RegistrationScreenComponent {

}
