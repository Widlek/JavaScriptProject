import { Component, EventEmitter, Input, Output } from '@angular/core';
import { ChatService } from '../chat.service';
import { UserService } from '../user.service';
import { CommonModule, NgIf } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { User } from '../user';

@Component({
  selector: 'app-login-screen',
  standalone: true,
  imports: [NgIf, CommonModule, FormsModule],
  templateUrl: './login-screen.component.html',
  styleUrl: './login-screen.component.css'
})
export class LoginScreenComponent {
  constructor(public chatService: ChatService, public userService: UserService){};

  username: string = "";
  password: string = "";
  repeatedPassword: string = "";

  registerSwitch: boolean = false;

  @Output() loginEvent = new EventEmitter<User>;

  switch(){
    this.registerSwitch = !this.registerSwitch;
  }

  login(){
    for(let i = 0; i < this.userService.userList.length; i++){
      if(this.userService.userList[i].name == this.username && this.password == this.userService.userList[i].password){
          this.loginEvent.emit(this.userService.userList[i]);
      }
    }
  }

  register(){
    if(this.password == this.repeatedPassword){
      let user = this.userService.createUser(this.username, this.password);
      this.loginEvent.emit(user);
    }
  }

}
