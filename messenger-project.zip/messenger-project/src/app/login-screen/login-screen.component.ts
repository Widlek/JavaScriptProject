import { Component } from '@angular/core';
import { ChatService } from '../chat.service';
import { UserService } from '../user.service';
import { CommonModule, NgIf } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-login-screen',
  standalone: true,
  imports: [NgIf, CommonModule, FormsModule],
  templateUrl: './login-screen.component.html',
  styleUrl: './login-screen.component.css'
})
export class LoginScreenComponent {
  constructor(public chatService: ChatService, public userService: UserService){};

  username: string = "";
  password: string = "";
  repeatedPassword: string = "";

  registerSwitch: boolean = false;

  switch(){
    this.registerSwitch = !this.registerSwitch;
  }

  login(){
    for(let i = 0; i < this.userService.userList.length; i++){
      if(this.userService.userList[i].name == this.username && this.password == this.userService.userList[i].password){
        sessionStorage.setItem("currentUser", this.userService.userList[i].id.toString());
      }
    }
  }

  register(){
    if(this.password == this.repeatedPassword){
      let id = this.userService.createUser(this.username, this.password).id;
      sessionStorage.setItem("currentUser", id.toString());
    }
  }

}
