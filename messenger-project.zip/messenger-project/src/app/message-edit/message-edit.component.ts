import { Component, Output, Input, EventEmitter } from '@angular/core';
import { Message } from '../message';

@Component({
  selector: 'app-message-edit',
  standalone: true,
  imports: [],
  templateUrl: './message-edit.component.html',
  styleUrl: './message-edit.component.css'
})
export class MessageEditComponent {

  delete: string = "delete";
  edit: string = "edit";

  @Output() messageIvent = new EventEmitter<{message: Message, action: string}>();
  @Input() message: Message | undefined = undefined;

  sendInfo(message: Message, action: string){
    if(this.message)
    this.messageIvent.emit({message, action});
  }

}
