import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Message } from '../message';
import { UserService } from '../user.service';
import { ChatService } from '../chat.service';

@Component({
  selector: 'app-message-edit',
  standalone: true,
  imports: [],
  templateUrl: './message-edit.component.html',
  styleUrl: './message-edit.component.css'
})
export class MessageEditComponent {
  constructor(public chatService: ChatService, public userService: UserService){};
  @Input() message: Message | undefined = undefined;


}
