export interface User {
    id: number,
    name: string,
    password: string,
    status: string | undefined,
    profilePicture: string | undefined,
}
