import { useState } from 'react'
import './App.css'
import List from './components/List'

function App() {
  const [count, setCount] = useState(0);

  let array = [1, 2, 3, 5, 7, 8, 9, 0];

  return (
    <>
      <List array={array}/>
    </>
  )
}

export default App
