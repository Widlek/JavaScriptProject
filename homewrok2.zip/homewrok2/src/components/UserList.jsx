import ListItem from "./ListItem";
import { useState } from "react";


function List(props){

    let [input, setInput] = useState('');
    let array = props.array;

    return (
        <>
        <h2>Task0.A: Создать компонент `List` для отображения списка элементов из массива. </h2>
           <ul>{array.map((item) =>(
            <>
                <ListItem item={item}/>
            </>
           ))}</ul> 
            <div>
                <div>Delete element №:</div>
                <input type="text" value={input} onInput={(event) => setInput(event.target.value)}/>
                <button onClick={()=>{array.splice(input, 1)}}>delete</button>
            </div>

        </>
    )

}s

export default List;