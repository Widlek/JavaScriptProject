function ListItem(props){

   return (

    <>
        <li>{props.item}</li>
    </>
   )


}

export default ListItem;