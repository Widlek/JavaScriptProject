import ListItem from "./ListItem";
import { useState } from "react";



function List(props){



    let [input, setInput] = useState('');
    let [array, setArray] = useState([10, 20, 30, 40, 50, 60, 70, 80, 90]);


    const deleteById = (index) => {
        const newArray = array.filter((item) => item != array[index]);
        setArray(newArray);
    }

    return (
        <>
        <h2>Task0.A: Создать компонент `List` для отображения списка элементов из массива. </h2>
           <ul>{array.map((item) =>(
            <>
                 <ListItem item={item}/>
            </>
           ))}</ul> 
            <div>
                <div>Delete element №:</div>
                <input type="text" value={input} onChange={event => setInput(event.target.value)}/>
                <button onClick={()=>{deleteById(input); console.log(array)}}>delete</button>
            </div>

        </>
    )

}

export default List;    