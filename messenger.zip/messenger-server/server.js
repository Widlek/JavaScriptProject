const express = require("express");
const fs = require("fs");
const cors = require('cors');
const bodyParser = require('body-parser')

const app = express();

let chatlistJson = fs.readFileSync('./data.json');
let chatlist = JSON.parse(chatlistJson);
let userListJson = fs.readFileSync('./users.json');
let userList  = JSON.parse(userListJson);

app.use(cors());

app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});

app.use(bodyParser.json())

app.get("/", function(request, response){
    response.send("<h1>123123<h1>")

})


app.post('/login', function(request, response){
    console.log(userList[0].name);

    let filteredChatlist = [];
    let userFound = false;
    let user = {

    }
    for(let i = 0; i < userList.length; i++){
        if(request.body.username == userList[i].name && request.body.password == userList[i].password){
            user = {
                id: userList[i].id,
                name: userList[i].name,
                profilePicture: userList[i].profilePicture,
                status: userList[i].status,
                displayedName: userList[i].displayedName,
            }   
            userFound = true;
        }
    }

    if(userFound){
        for(let i = 0; i < chatlist.length; i++){
            for(let b = 0; b < chatlist[i].members.length; b++){
                if(chatlist[i].members[b].name == request.body.username && chatlist[i].members[b].password == request.body.password){
                    filteredChatlist.push(chatlist[i]);
                }
            }
        }
    }

    console.log(filteredChatlist);
    response.send(JSON.stringify({filteredChatlist, user}));
})


app.post('/sendMessage', function(request, response){
    for(let i = 0; i < chatlist.length; i++){
        if(chatlist[i].id == request.body.chat.id){
            chatlist[i].messages.push(request.body.message);
            response.sendStatus(200);
            return;
        }
    }

    response.sendStatus(400);
    return;
})

app.post('/update', function(request, response){

    let filteredChatlist = [];

    for(let i = 0; i < chatlist.length; i++){
        for(let b = 0; b < chatlist[i].members.length; b++){
            if(chatlist[i].members[b].name == request.body.username){
                filteredChatlist.push(chatlist[i]);
            }
        }
    }
    response.send(filteredChatlist);
    return;
})

app.listen(3000);