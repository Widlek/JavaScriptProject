const express = require("express");console
const fs = require("fs");
const cors = require('cors');
const bodyParser = require('body-parser');
const { resourceUsage } = require("process");

const app = express();

let chatlistJson = fs.readFileSync('./data.json');
let chatlist = JSON.parse(chatlistJson);
let userListJson = fs.readFileSync('./users.json');
let userList  = JSON.parse(userListJson);

app.use(cors());

app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});

app.use(bodyParser.json())

app.get("/", function(request, response){
    response.send("<h1>123123<h1>")

})


app.post('/login', function(request, response){
    console.log(request.body.username);

    let filteredChatlist = [];
    let userFound = false;
    let user = {

    }
    for(let i = 0; i < userList.length; i++){
        if(request.body.username == userList[i].name && request.body.password == userList[i].password){
            user = {
                id: userList[i].id,
                name: userList[i].name,
                profilePicture: userList[i].profilePicture,
                status: userList[i].status,
                displayedName: userList[i].displayedName,
            }   
            userFound = true;
        }
    }

    if(userFound){
        for(let i = 0; i < chatlist.length; i++){
            for(let b = 0; b < chatlist[i].members.length; b++){
                if(chatlist[i].members[b].name == request.body.username && chatlist[i].members[b].password == request.body.password){
                    filteredChatlist.push(chatlist[i]);
                }
            }
        }
    }


    response.send(JSON.stringify({filteredChatlist, user}));
})


app.post('/sendMessage', function(request, response){

    if(request.body.message && request.body.chat){
        chatlist[request.body.chat.id].messages.push(request.body.message);
        response.sendStatus(200);
        return;
    }
    response.sendStatus(400);

})

app.post('/update', function(request, response){
    let filteredChatlist = [];

    for(let i = 0; i < chatlist.length; i++){
        for(let b = 0; b < chatlist[i].members.length; b++){
            if(chatlist[i].members[b].name == request.body.username){
                filteredChatlist.push(chatlist[i]);
            }
        }
    }
    response.send(filteredChatlist);
    return;
})

app.post('/edit', function(request, response){
    chatlist[request.body.chat.id].messages[request.body.msg.id].text = request.body.text;
    response.sendStatus(200);
})

app.post('/deleteMessage', function(request, response){
    chatlist[request.body.chat.id].messages.splice(request.body.msg.id, 1);
    response.sendStatus(200);
    return;
})

app.delete('/leave', function(request, response){
    console.log(request.body.chat.id);
    for(let i = 0; i < chatlist[request.body.chat.id].members.length; i++){
        if(chatlist[request.body.chat.id].members[i].id == request.body.user.id){
            chatlist[request.body.chat.id].members.splice(i, 1);
        }
    }
})

app.post('/register', function(request, response){

    let filteredChatlist = [];

    for(let i = 0; i < userList.length; i++){
        if(userList[i].name == request.body.name){
            response.send(400);
            return;
        }
    }
    
    let newUser = {
        id: userList.length,
        name: request.body.name,
        password: request.body.password,
        profilePicture: "",
        status: "",
        displayedName: "",
    }
    
    chatlist[0].members.push(newUser);
    userList.push(newUser);
    filteredChatlist.push(chatlist[0]);
    
    
    console.log(filteredChatlist);
    response.send(JSON.stringify({filteredChatlist, newUser}));
})

app.post('/userlist', function(request, response){
    let tempUserlist = [];
    for(let i = 0; i < userList.length; i++){
        if(userList[i].id != request.body.user.id){
            tempUserlist.push(userList[i]);
        }
    }
    response.send(tempUserlist);
})

app.post('/createChat', function(request, response){
    let newChat = {
        id: chatlist.length,
        name: request.body.chatName,
        messages: [],
        members: request.body.userlist,
        picture: "",
        owner: request.body.owner,

    }
    chatlist.push(newChat);
    console.log(chatlist);
    response.sendStatus(200);
})

app.post('/editchat', function(request, response){
    chatlist[request.body.chat.id].members = request.body.userlist;
    chatlist[request.body.chat.id].name = request.body.chatName;
    response.sendStatus(200);
})

app.listen(3000);