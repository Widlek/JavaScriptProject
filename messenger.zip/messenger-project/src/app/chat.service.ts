import { Injectable } from '@angular/core';
import { Chat } from './chat';
import { Message } from './message';
import { User } from './user';

@Injectable({
  providedIn: 'root'
})
export class ChatService {
  chatList: Chat[] = [];

  findChatById(id:number):Chat | undefined  {
    for(let i = 0; i < this.chatList.length; i++){
      if(this.chatList[i].id == id){
        return this.chatList[i];
      }
    }
    return undefined;
  }

  getChatListPosition(chat:Chat): number | undefined {
    for(let i = 0; i < this.chatList.length; i++){
      if(this.chatList[i] == chat){
        return i;
      }
    }
    return undefined;
  }

  createChat(name: string, members?: User[], picture?: string, messages?: Message[]){
    let chat:Chat = {
      id: this.chatList.length,
      name: name,
      members: members || [],
      picture: picture || "",
      messages: messages || [],
    }
    this.chatList.push(chat);
    return chat;
  }

  sendMessage(chat: Chat, message: Message){
    chat.messages.push(message);
  }

  deleteUserById(chat:Chat, id: number){
    for(let i = 0 ; i < chat.members.length; i++){
      if(chat.members[i].id == id){
        
        chat.members.splice(i, 1);
      }
    }
  }

  deleteUser(chat:Chat, user:User){
    for(let i = 0; i < chat.members.length; i++){
      if(chat.members[i] == user){
        chat.members.splice(i, 1);
      }
    }
  }

  deleteMessage(chat:Chat | undefined, message: Message | undefined){
    if(chat && message)
    for(let i = 0; i < chat.messages.length; i++){
      if(chat.messages[i] == message){
        chat.messages.splice(i, 1);
      }
    }
    return chat;
  }

  selectedChat: Chat | undefined = undefined;

  setSelectedChat(chat:Chat | undefined){
    this.selectedChat = chat;
  }

  getSelectedChat(){
    return this.selectedChat;
  }

  constructor() { }

}
