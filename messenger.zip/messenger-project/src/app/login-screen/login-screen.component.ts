import { Component, EventEmitter, Input, Output } from '@angular/core';
import { ChatService } from '../chat.service';
import { UserService } from '../user.service';
import { CommonModule, NgIf, NgStyle } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { User } from '../user';
import { Chat } from '../chat';
import { Ng2BootstrapModule } from 'ng-bootstrap';

@Component({
  selector: 'app-login-screen',
  standalone: true,
  imports: [NgIf, CommonModule, FormsModule, NgStyle],
  templateUrl: './login-screen.component.html',
  styleUrl: './login-screen.component.css'
})
export class LoginScreenComponent {
  constructor(public chatService: ChatService, public userService: UserService){};

  username: string = "";
  password: string = "";
  repeatedPassword: string = "";

  registerSwitch: boolean = false;

  @Output() loginEvent = new EventEmitter<Chat[]>;

  switch(){
    this.registerSwitch = !this.registerSwitch;
  }

  async login(){

    let res = await fetch("http://localhost:3000/login", {
      method:"POST",
      body: JSON.stringify({
        username: this.username,
        password: this.password,
      }),
      headers: {
        "Content-type": "application/json; charset=UTF-8",
      }


    })


    let data = await res.json();
    if(res){
      this.userService.setCurrentUser(data.user);
    }
    this.loginEvent.emit(data.filteredChatlist);
    console.log(data);

  }

  async register(){
    if(this.password == this.repeatedPassword){
      let response = await fetch('http://localhost:3000/register', {
        method: 'POST',
        body: JSON.stringify({
          name: this.username,
          password: this.password,
        }),
        headers: {
          "Content-type": "application/json; charset=UTF-8",
        }
      })
      let data = await response.json();
      console.log("----------------------------------");
      console.log(data.user);
      console.log(data.filteredChatlist);
      console.log("----------------------------------");
      this.userService.setCurrentUser(data.newUser);
      this.loginEvent.emit(data.filteredChatlist);
    }

    
  }

}
