import { Component, EventEmitter, Input, Output } from '@angular/core';
import { ChatService } from '../chat.service';
import { UserService } from '../user.service';
import { CommonModule, NgIf } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { User } from '../user';
import { Chat } from '../chat';

@Component({
  selector: 'app-login-screen',
  standalone: true,
  imports: [NgIf, CommonModule, FormsModule],
  templateUrl: './login-screen.component.html',
  styleUrl: './login-screen.component.css'
})
export class LoginScreenComponent {
  constructor(public chatService: ChatService, public userService: UserService){};

  username: string = "";
  password: string = "";
  repeatedPassword: string = "";

  registerSwitch: boolean = false;

  @Output() loginEvent = new EventEmitter<Chat[]>;

  switch(){
    this.registerSwitch = !this.registerSwitch;
  }

  async login(){

    let res = await fetch("http://localhost:3000/login", {
      method:"POST",
      body: JSON.stringify({
        username: this.username,
        password: this.password,
      }),


    })


    let data = await res.json();
    if(res){
      this.userService.setCurrentUser(data.user);
    }
    this.loginEvent.emit(data.filteredChatlist);
    console.log(data);

  }

  register(){
    if(this.password == this.repeatedPassword){
      let user = this.userService.createUser(this.username, this.password);
      // this.loginEvent.emit(user);
    }
  }

}
