import { Component, EventEmitter, Input, Output } from '@angular/core';
import { ChatService } from '../chat.service';
import { UserService } from '../user.service';
import { User } from '../user';
import { Chat } from '../chat';
import { UserPrewievComponent } from '../user-prewiev/user-prewiev.component';
import { CheckboxUser } from '../checkboxUser';
import { FormsModule, NgModel } from '@angular/forms';

@Component({
  selector: 'app-chat-creation',
  standalone: true,
  imports: [UserPrewievComponent, FormsModule],
  templateUrl: './chat-creation.component.html',
  styleUrl: './chat-creation.component.css'
})
export class ChatCreationComponent {
  constructor(public chatService: ChatService, public userService: UserService){};

  @Input() checkedUsers: CheckboxUser[] = [];
  @Output() toggle = new EventEmitter<any[]>();
  @Output() create = new EventEmitter<string>();
  @Output() backEvent = new EventEmitter<string>();

  chatName:string ="";

  onToggle(){
    const checkedOptions = this.checkedUsers.filter(x => x.checked);
    this.toggle.emit(checkedOptions.map(x => x.user));
  }

  createChat(){
    this.create.emit(this.chatName);
  }

  getBack(){
    this.backEvent.emit('back');
  }

}
