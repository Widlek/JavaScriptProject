import { Injectable } from '@angular/core';
import { CheckboxUser } from './checkboxUser';

@Injectable({
  providedIn: 'root'
})

export class checkboxUserService {

  constructor() {}
 }
