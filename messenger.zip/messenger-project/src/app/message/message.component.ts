import { NgClass, NgIf } from '@angular/common';
import { Component, EventEmitter, Input, Output, } from '@angular/core';
import { Message } from '../message';
import { MessageEditComponent } from '../message-edit/message-edit.component';
import { ChatService } from '../chat.service';
import { UserService } from '../user.service';

@Component({
  selector: 'app-message',
  standalone: true,
  imports: [NgIf, MessageEditComponent, NgClass],
  templateUrl: './message.component.html',
  styleUrl: './message.component.css'
})
export class MessageComponent {
  constructor(public chatService: ChatService, public userService: UserService){};
  @Input() message: Message | undefined = undefined;

  @Output() messageSelect = new EventEmitter<Message>();

  checkMessage(){
    if(this.message?.sender == this.userService.getCurrentUser()){
      this.messageSelect.emit(this.message);
    }
  }

}
