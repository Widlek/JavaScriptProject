import { Component, EventEmitter, Output } from '@angular/core';
import { Input } from '@angular/core';
import { Chat } from '../chat';
import { NgClass, NgIf, NgStyle } from '@angular/common';
import { FormsModule, NgModel, NgSelectOption } from '@angular/forms';
import { Message } from '../message';
import { ChatService } from '../chat.service';
import { UserService } from '../user.service';
import { User } from '../user';
import { MessageComponent } from '../message/message.component';
import { MessageEditComponent } from '../message-edit/message-edit.component';
import { interval } from 'rxjs';
import { ParseSourceFile } from '@angular/compiler';
import { CheckboxUser } from '../checkboxUser';

@Component({
  selector: 'app-chat',
  standalone: true,
  imports: [NgIf, FormsModule, MessageComponent, NgClass, MessageEditComponent, NgStyle],
  templateUrl: './chat.component.html',
  styleUrl: './chat.component.css'
})

export class ChatComponent {
  constructor(public chatService: ChatService, public userService: UserService){};
  @Input() chat:Chat | undefined = undefined;
  @Input() user: User | undefined = undefined;

  @Output() editEvent = new EventEmitter<CheckboxUser[]>();

  text: string = "";

  editing: boolean = false;

  selectedMessage: Message | undefined = undefined;

  x:string = '0px';
  y:string = '0px';

  mouseUpdate(event: MouseEvent){
    this.x = (event.pageX + 15).toString() + 'px';
    this.y = (event.pageY - 15).toString() + 'px';

    console.log(this.x, this.y);

  }

  checkedUsers: CheckboxUser[] = [];

  async deleteMessage(message: Message){
   
    let response = await fetch('http://localhost:3000/deleteMessage', {
      method: 'POST',
      body:JSON.stringify({
        chat: this.chatService.getSelectedChat(),
        msg: message,
      }),
      headers: {
        "Content-type": "application/json; charset=UTF-8",
      }
    })
    
  }

  async editMessage(message: Message){
    if(this.text != "" && this.text != undefined){
      let response = await fetch('http://localhost:3000/edit', {
        method: 'POST',
        body:JSON.stringify({
          chat: this.chatService.getSelectedChat(),
          msg: message,
          text: this.text
        }),
        headers: {
          "Content-type": "application/json; charset=UTF-8",
        }
      })
    }
  }

  async sendMessage(){
    if(this.text != "" && this.chatService.selectedChat){

      if(this.editing == true && this.selectedMessage){
        this.editMessage(this.selectedMessage);
        this.editing = false;
        return;
      }

      let newMessage:Message = {
        text: this.text,
        date: new Date(),
        sender: this.userService.getCurrentUser(),
        id: this.chatService.selectedChat.messages.length
      }

      if(this.chat){

        let response = await fetch('http://localhost:3000/sendMessage', {
          method: "POST",
          body: JSON.stringify({
            chat: this.chatService.getSelectedChat(),
            message: newMessage,
          }),
          headers: {
            "Content-type": "application/json; charset=UTF-8",
          }
        })
      }
    }

  }

  invisible: boolean = true;
  toggle(message: Message){
    console.log(123);
    this.selectedMessage = message;
    this.invisible = false;
  }

  update(){
    if(this.chatService.selectedChat != undefined){
      for(let i = 0; i < this.chatService.chatList.length; i++){
        if(this.chatService.selectedChat.id == this.chatService.chatList[i].id){
          this.chatService.setSelectedChat(this.chatService.chatList[i]);
        }
      }
    }
  }

  editMenu(type: string){
    if(type == "delete" && this.selectedMessage){
      this.deleteMessage(this.selectedMessage);
      this.selectedMessage = undefined;
      this.invisible = true;
    }
    else{
      this.editing = true;
      this.invisible = true;
    }
  }

  ngOnInit(){
    const updateInterval = interval(500);
    updateInterval.subscribe((count: number)=>{
      this.update()
    })
  }

  async getChatlist(){
    let response = await fetch('http://localhost:3000/userlist', {
      method: 'POST',
      body: JSON.stringify({
        user: this.userService.getCurrentUser(),
      }),
      headers: {
        "Content-type": "application/json; charset=UTF-8",
      }
    })

    this.userService.userList = await response.json();

    

    if(this.chatService.selectedChat){
      let idArray = this.chatService.selectedChat?.members.map(x => x.id);
      for(let i = 0; i < this.userService.userList.length; i++){
  
        if(idArray.includes(this.userService.userList[i].id)){
          this.checkedUsers[i] = {
            user :this.userService.userList[i],
            checked: true,
          }
        }
        else{
          this.checkedUsers[i] = {
            user :this.userService.userList[i],
            checked: false,
          }
        }
      }
    }

    this.editEvent.emit(this.checkedUsers);

  }

}
