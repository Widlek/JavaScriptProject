import { User } from "./user";

export interface CheckboxUser {
    user: User,
    checked: boolean;
   
}