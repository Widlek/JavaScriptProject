import { Component, inject } from '@angular/core';
import { ChatPreviewComponent } from '../chat-preview/chat-preview.component';
import { ChatService } from '../chat.service';
import { UserService } from '../user.service';
import { Message } from '../message';
import { Chat } from '../chat';
import { NgIf } from '@angular/common';
import { ChatComponent } from '../chat/chat.component';
import { LoginScreenComponent } from '../login-screen/login-screen.component';
import { User } from '../user';
import { interval } from 'rxjs';

@Component({
  selector: 'app-chatlist',
  standalone: true,
  imports: [ChatlistComponent, ChatPreviewComponent, NgIf, ChatComponent, LoginScreenComponent],
  templateUrl: './chatlist.component.html',
  styleUrl: './chatlist.component.css'
})


export class ChatlistComponent {
  constructor(public chatService: ChatService, public userService: UserService){};
  testChat:Chat = this.chatService.createChat("test chat", this.userService.userList);
  testChat2:Chat = this.chatService.createChat("test chat 2", this.userService.userList);

  filteredChats: Chat[] | undefined = [];

  testMsg: Message = {
    text: "Hello world!",
    date: undefined,
    sender: undefined,
  }

  ngOnInit(){
    this.chatService.sendMessage(this.testChat2, this.testMsg);
    this.userService.createUser("testUser", "123");
    this.userService.createUser("User2", "1234");
    let data = JSON.stringify(this.userService.userList);
    console.log(data);
    const updateInterval = interval(500);
    updateInterval.subscribe((count: number)=>{
      this.update()
    })
  }

  setChat(value: Chat | undefined){
    console.log(value);
    this.chatService.setSelectedChat(value);
    return value;
  }
  
  async update(){
    if(this.userService.currentUser != undefined){
      let response = await fetch('http://localhost:3000/update', {
        method: 'POST',
        body:JSON.stringify({
          username: this.userService.currentUser.name,
          password: this.userService.currentUser.password,
        }),
        headers: {
          "Content-type": "application/json; charset=UTF-8",
        }
      })
  
      let data = await response.json();
      
      this.chatService.chatList = data;
    }
  }



  setChatlist(chatlist: Chat[]){
    if(chatlist){
      console.log(chatlist)
      this.chatService.chatList = chatlist;
      this.filteredChats = chatlist;
    }
  }

}
