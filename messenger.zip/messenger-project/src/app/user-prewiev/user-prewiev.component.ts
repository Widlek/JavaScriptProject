import { Component, Input, Output } from '@angular/core';
import { User } from '../user';
import { CheckboxUser } from '../checkboxUser';

@Component({
  selector: 'app-user-prewiev',
  standalone: true,
  imports: [],
  templateUrl: './user-prewiev.component.html',
  styleUrl: './user-prewiev.component.css'
})
export class UserPrewievComponent {
  @Input() user:CheckboxUser | undefined = undefined;




}
