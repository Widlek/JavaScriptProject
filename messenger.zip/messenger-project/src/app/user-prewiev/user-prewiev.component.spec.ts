import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserPrewievComponent } from './user-prewiev.component';

describe('UserPrewievComponent', () => {
  let component: UserPrewievComponent;
  let fixture: ComponentFixture<UserPrewievComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [UserPrewievComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(UserPrewievComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
