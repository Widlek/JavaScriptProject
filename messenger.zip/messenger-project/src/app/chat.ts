import { Message } from "./message";
import { User } from "./user";

export interface Chat {
    id: number,
    name: string,
    messages:  Message[],
    members: User[],
    picture: string,
    owner: User | undefined,
}
