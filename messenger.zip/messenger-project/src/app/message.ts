import { User } from "./user";

export interface Message {
    text: string,
    date: Date | undefined,
    sender: User | undefined,
    id: number,
}
