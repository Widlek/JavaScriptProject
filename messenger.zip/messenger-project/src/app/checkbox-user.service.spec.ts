import { TestBed } from '@angular/core/testing';

import { CheckboxUserService } from './checkbox-user.service';

describe('CheckboxUserService', () => {
  let service: CheckboxUserService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CheckboxUserService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
