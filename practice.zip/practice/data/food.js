const fs = require("fs");


let food = [];

function getRandomInt(max) {
    return Math.floor(Math.random() * max);
}

const foodNames = ["pizza", "burger", "pasta", "paella", "borsch", "sushi-rolls", "onion soup", "meatballs"];

function getRandomFoodName(){
    return foodNames[getRandomInt(foodNames.length - 1)];
}

function getRandomValue(){
    if(getRandomInt(101) > 50){
        return;
    }
    else{
        return getRandomInt(1000) + 1;
    }
}

function clearFromDuplicats(array) { 
    return array.filter((item, index) => array.indexOf(item) === index); 
} 

function getRandomImage(){
    const images = fs.readdirSync(`./public/images/`);
    let returnedArray = [];
    for(let i = 0; i < getRandomInt(3); i++){
        returnedArray.push(images[getRandomInt(images.length - 1)]);
        clearFromDuplicats(returnedArray);
        return returnedArray;
    }

}

for(let i = 0; i < getRandomInt(20); i++){
    let arrayElement = {
        name: getRandomFoodName(),
        ccal: getRandomValue(),
        fats: getRandomValue(),
        proteins: getRandomValue(),
        carbohydrates: getRandomValue(),
        images: getRandomImage(),
    }
    food.push(arrayElement);
}

